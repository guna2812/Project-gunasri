Select * From coursesinfo

Select * From studentinfo

Select * From enrollment_info

