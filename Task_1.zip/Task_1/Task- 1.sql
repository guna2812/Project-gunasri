--Select * From coursesinfo

--Select * From studentinfo

--Select * From enrollment_info

-- ******** a ******** --

select s.stu_name,s.phone_no,s.email_id,s.address,e.enroll_status

from studentinfo s , enrollment_info e

where s.stu_id = e.stu_id;


-- ******** b ******** --
select c.course_name ,e.enroll_status 

from studentinfo s , enrollment_info e , coursesinfo c

where c.Course_ID = e.COURSE_ID and e.STU_ID = s.STU_ID and s.STU_NAME = 'Naveen'

and e.enroll_status = 'Enrolled'

-- ******** c ******** --
select course_name , course_instructor_name 

 from coursesinfo ;

-- ******** d ******** --
select * 

from coursesinfo WHERE course_name = 'SQL';

-- ******** e ******** --
select * 

from coursesinfo WHERE course_name in ('SQL','Python');

-- Reporting and Analytics --
-- ******** a ******** --
select c.course_name , count(e.stu_id) 
FROM coursesinfo c
INNER JOIN enrollment_info e ON c.Course_ID = e.COURSE_ID
where e.enroll_status = 'Enrolled'
GROUP BY c.Course_Name;

-- ******** b ******** --
select c.course_name , count(e.stu_id) 
FROM coursesinfo c
INNER JOIN enrollment_info e ON c.Course_ID = e.COURSE_ID
WHERE c.course_name = 'SQL' and e.enroll_status = 'Enrolled'
GROUP BY c.Course_Name

-- ******** c ******** --
select c.course_instructor_name , count(e.stu_id) 
FROM coursesinfo c
INNER JOIN enrollment_info e ON c.Course_ID = e.COURSE_ID
where e.enroll_status = 'Enrolled'
GROUP BY c.course_instructor_name

-- ******** d ******** --
select count(c.course_name ) as CoursesEnrolled, s.stu_name
FROM coursesinfo c
INNER JOIN enrollment_info e ON c.Course_ID = e.COURSE_ID
INNER JOIN studentinfo s ON s.stu_id = e.stu_id
where e.enroll_status = 'Enrolled'
GROUP BY s.stu_name
Having count(c.course_name) >1

-- ******** e ******** --
Select c.course_name, COUNT(e.stu_id) AS num_students
from coursesinfo c
INNER JOIN enrollment_info e ON c.Course_ID = e.COURSE_ID
where e.enroll_status = 'Enrolled'
GROUP BY c.course_name
ORDER BY num_students DESC

