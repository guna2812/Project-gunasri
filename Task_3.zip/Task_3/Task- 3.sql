--------- 1.Database Creation ---------

select * from events;

select * from attendees;

select * from registrations;

--------- 2.Data Creation ---------
-- Insert data into the Events table
INSERT INTO Events (event_id ,Event_Name, Event_Date, Event_Location, Event_Description)
VALUES
    (101,'Event A', '2023-11-15', 'Location A', 'Description A'),
    (102,'Event B', '2023-12-20', 'Location B', 'Description B'),
    (103,'Event C', '2024-01-25', 'Location C', 'Description C');

-- Insert data into the Attendees table
INSERT INTO Attendees (attendee_id,Attendee_Name, Attendee_Phone, Attendee_Email, Attendee_City)
VALUES
    (1,'Ravi', '1234567890', 'ravi@email.com', 'City X'),
    (2,'Vinoth', '9876543210', 'vino@email.com', 'City Y'),
    (3,'Preetha', '5551234567', 'pree@email.com', 'City Z');

-- Insert data into the Registrations table
INSERT INTO Registrations (registration_id,Event_Id, Attendee_Id, Registration_Date, Registration_Amount)
VALUES
    (1801,101, 1, '2023-10-05', 50.00),
    (1802,102, 2, '2023-11-10', 75.00),
    (1803,101, 3, '2023-12-20', 50.00);


--------- 3.Manage event details ---------
-- a.Inserting a new event

INSERT INTO Events (event_id,Event_Name, Event_Date, Event_Location, Event_Description)
VALUES
    (104,'Event D', '2024-02-10', 'Location D', 'Description D');

-- b.Updating an event's information

UPDATE Events
SET
    Event_Name = 'Event AA',
    Event_Date = '2023-11-25',
    Event_Location = 'Location AA',
    Event_Description = 'Description AA'
WHERE Event_Id = 101;

-- c.Deleting an event

DELETE FROM Events
WHERE Event_Id = 103;

--------- 4.Manage track attendees & handle events ---------
-- a.Inserting a new attendee

INSERT INTO Attendees (attendee_id,Attendee_Name, Attendee_Phone, Attendee_Email, Attendee_City)
VALUES
    (4,'Vishnu', '9793728934', 'vish@email.com', 'City AA');

-- b.Registering an attendee for an event

INSERT INTO Registrations (registration_id,Event_Id, Attendee_Id, Registration_Date, Registration_Amount)
VALUES
    (1804,104,4, '2024-01-05', 50.00);
	
--------- 5.To retrieve event information ---------

select * from events;

--------- 5.generate attendee lists ---------

SELECT a.attendee_id,a.attendee_name,a.attendee_email,e.event_name,e.event_date
FROM registrations r
JOIN attendees a ON r.attendee_id = a.attendee_id
JOIN events e ON r.event_id = e.event_id
WHERE e.event_id = 101;

--------- 5.calculate event attendance statistics ---------

SELECT e.event_id,e.event_name,SUM(r.registration_amount) AS TotalAmount
FROM events e
JOIN registrations r ON e.event_id = r.event_id
WHERE e.event_id = 101
GROUP BY  e.event_id,e.event_name;







