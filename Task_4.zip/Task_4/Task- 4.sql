-------- 1.Database Creation ------
select * from sales_sample

--------- 2.Data Creation ---------

INSERT INTO sales_sample (product_id, region, date, sales_amount)
VALUES
    (1, 'East', '2023-11-01', 1000),
    (2, 'West', '2023-11-02', 1500),
    (3, 'North', '2023-11-03', 1200),
    (4, 'South', '2023-11-04', 800),
    (5, 'East', '2023-11-05', 2000),
    (1, 'South', '2023-11-06', 1300),
    (2, 'West', '2023-11-07', 900),
    (3, 'North', '2023-11-08', 1800),
    (4, 'North', '2023-11-09', 1100),
    (5, 'West', '2023-11-10', 1600);

--------- 3.Perform OLAP Operations ---------
-- a.Drill Down

select product_id, region,SUM(sales_amount) AS TotalSales
from sales_sample
group by product_id, region
order by product_id, region DESC;

-- b.Roll up

select region, SUM(sales_amount) AS TotalSales
from sales_sample
group by ROLLUP(Region);

-- c.Cube

select product_id, region, DATE_TRUNC('month', date) AS Month, SUM(sales_amount) AS TotalSales
from sales_sample
group by CUBE(product_id, region, DATE_TRUNC('month', date))
order by product_id, region, Month;

-- d.Slice

select region, DATE_TRUNC('month', date) AS Month, SUM(sales_amount) AS TotalSales
from sales_sample
where region = 'North' AND date BETWEEN '2023-11-02' AND '2023-11-10'
group by region, DATE_TRUNC('month', date)
order by Month;

-- e.Dice

select product_id, region, DATE_TRUNC('month', date) AS Month, SUM(sales_amount) AS TotalSales
from sales_sample
where (product_id = '1' OR product_id = '5')
  and region = 'East'
  and date BETWEEN '2023-11-01' AND '2023-11-07'
group by product_id, region, DATE_TRUNC('month', date)
order by product_id, region, Month;




