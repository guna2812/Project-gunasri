------ 1 .Database Setup ----------
Select * from student_table

------ 2.Data Entry ----------

INSERT INTO student_table (Student_id, Stu_name, Department, email_id, Phone_no, Address, Date_of_birth, Gender, Major, GPA, Grade)
VALUES
    (1, 'John', 'Engineering', 'john@example.com', 1234567890, '123 Main St', '1995-05-15', 'Male', 'Computer Science', 7.5, 'B'),
    (2, 'Joshva', 'Business', 'josh@example.com', 9876543210, '456 2nd cross St', '1994-09-20', 'Male', 'Marketing', 3.5, 'C'),
    (3, 'Manik', 'Science', 'manik@example.com', 5555555555, '789 new colony Road', '1996-07-10', 'Male', 'Biology', 8.2, 'A'),
    (4, 'Sarah', 'Engineering', 'sarah123@example.com', 3333333333, '101 Radha nagar', '1995-02-03', 'Female', 'Electrical Engineering', 3.9, 'C'),
    (5, 'David', 'Arts', 'david97@example.com', 7777777777, '222 vivekananda St', '1997-11-30', 'Male', 'History', 6.5, 'B'),
    (6, 'Jandiya', 'Business', 'jan@example.com', 9999999999, '333 Shanthi colony', '1994-04-25', 'Female', 'Finance', 8.0, 'A'),
    (7, 'Adhvaith', 'Science', 'adv@example.com', 4444444444, '444 bharathiyar St', '1996-03-12', 'Male', 'Chemistry', 5.5, 'B'),
    (8, 'Aneefa', 'Engineering', 'aneef08@example.com', 2222222222, '555 church road', '1995-08-08', 'Male', 'Mechanical Engineering', 4.5, 'C'),
    (9, 'Janvi', 'Arts', 'janu@example.com', 6666666666, '666 ring road', '1997-12-18', 'Female', 'English', 9.2, 'A'),
    (10, 'Preetha', 'Business', 'preetha@example.com', 1111111111, '777 VM st', '1994-06-19', 'Female', 'Management', 7.5, 'B');
	
------ 3.Student Information Retrieval ----------		
Select * from student_table
order by grade desc;

------ 4.Query for male students ----------		
Select * from student_table
where gender = 'Male';
	
------ 5.Query for students with GPA less than 5.0 ----------		
Select * from student_table
where gpa < 5.0;	

------ 6.Update Student Email and Grade ----------		
Update student_table SET email_id ='josh20@example.com', gpa = 6.5 , grade = 'B'
where student_id = 2

Select student_id ,stu_name ,email_id , gpa,grade from student_info where student_id = 2;

------ 7.Query for students with grade "B" ----------		
Select stu_name , DATE_PART('year', AGE(CURRENT_DATE, date_of_birth)) AS Age
from student_table
where grade = 'B';

------ 8.Grouping and Calculation ----------		
Select department , gender , avg(gpa)
from student_table
Group by department , gender
	
------ 9.Table Renaming ----------		
Alter table student_table rename to student_info

Select * from student_info	

------ 10.Retrieve Students with Highest GPA  ----------		
Select stu_name 
from student_info
where gpa = (select max(gpa) from student_info )

